import { exec } from 'child_process';
import { promisify } from 'util';
import * as fs from 'fs/promises';
import * as path from 'path';
import logger from '../utils/logger';

// Lazy loading do Puppeteer - só importa quando necessário (não durante build)
let puppeteer: any = null;
async function getPuppeteer() {
  if (!puppeteer) {
    puppeteer = await import('puppeteer');
  }
  return puppeteer;
}

const execAsync = promisify(exec);

interface WhatsAppVersion {
  version: string;
  timestamp: Date;
  source: 'web.whatsapp.com' | 'manual';
}

interface VersionCheckResult {
  currentVersion: string;
  latestVersion: string;
  needsUpdate: boolean;
  updated: boolean;
  error?: string;
}

class WhatsAppVersionMonitor {
  private browser: any = null;
  private isChecking: boolean = false;
  private lastCheck: Date | null = null;
  private currentVersion: string | null = null;

  // Caminho do docker-compose na VPS
  private readonly DOCKER_COMPOSE_PATH = '/root/ferraco-crm/docker-compose.vps.yml';

  constructor() {
    this.loadCurrentVersion();
  }

  /**
   * Carrega a versão atual do docker-compose
   */
  private async loadCurrentVersion(): Promise<void> {
    try {
      const dockerComposePath = path.join(process.cwd(), '../../docker-compose.vps.yml');
      const content = await fs.readFile(dockerComposePath, 'utf-8');

      const match = content.match(/CONFIG_SESSION_PHONE_VERSION=([0-9.]+)/);
      if (match) {
        this.currentVersion = match[1];
        logger.info('📱 Versão atual do WhatsApp Web:', { version: this.currentVersion });
      }
    } catch (error: any) {
      logger.warn('⚠️ Não foi possível carregar versão atual:', error.message);
    }
  }

  /**
   * Busca a versão atual do WhatsApp Web usando Puppeteer
   */
  async fetchLatestVersion(): Promise<string> {
    let browser: any = null;

    try {
      logger.info('🌐 Acessando web.whatsapp.com para verificar versão...');

      const pptr = await getPuppeteer();
      browser = await pptr.default.launch({
        headless: true,
        args: [
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-dev-shm-usage',
          '--disable-gpu',
          '--disable-software-rasterizer',
          '--disable-extensions',
        ],
      });

      const page = await browser.newPage();

      // Timeout de 60 segundos
      page.setDefaultTimeout(60000);

      // Acessar WhatsApp Web
      await page.goto('https://web.whatsapp.com', {
        waitUntil: 'domcontentloaded',
      });

      // Aguardar um pouco para garantir que o JavaScript carregou
      await page.waitForTimeout(5000);

      // Extrair versão do window.Debug
      const version = await page.evaluate(() => {
        // @ts-ignore
        if (window.Debug && window.Debug.VERSION) {
          // @ts-ignore
          return window.Debug.VERSION;
        }
        return null;
      });

      if (!version) {
        throw new Error('Não foi possível extrair versão do WhatsApp Web');
      }

      logger.info('✅ Versão detectada:', { version });
      return version;

    } catch (error: any) {
      logger.error('❌ Erro ao buscar versão do WhatsApp Web:', error.message);
      throw error;
    } finally {
      if (browser) {
        await browser.close();
      }
    }
  }

  /**
   * Atualiza o docker-compose.vps.yml com a nova versão
   */
  private async updateDockerCompose(newVersion: string): Promise<boolean> {
    try {
      const dockerComposePath = path.join(process.cwd(), '../../docker-compose.vps.yml');

      // Ler arquivo atual
      let content = await fs.readFile(dockerComposePath, 'utf-8');

      // Substituir versão
      const oldPattern = /CONFIG_SESSION_PHONE_VERSION=[0-9.]+/;
      const newValue = `CONFIG_SESSION_PHONE_VERSION=${newVersion}`;

      if (!oldPattern.test(content)) {
        throw new Error('Padrão CONFIG_SESSION_PHONE_VERSION não encontrado no docker-compose.vps.yml');
      }

      content = content.replace(oldPattern, newValue);

      // Salvar arquivo
      await fs.writeFile(dockerComposePath, content, 'utf-8');

      logger.info('✅ docker-compose.vps.yml atualizado com sucesso');
      return true;

    } catch (error: any) {
      logger.error('❌ Erro ao atualizar docker-compose.vps.yml:', error.message);
      return false;
    }
  }

  /**
   * Reinicia apenas o container Evolution API
   */
  private async restartEvolutionContainer(): Promise<boolean> {
    try {
      logger.info('🔄 Reiniciando container Evolution API...');

      const dockerComposePath = path.join(process.cwd(), '../..');

      // Restart apenas o serviço evolution-api
      await execAsync('docker-compose -f docker-compose.vps.yml restart evolution-api', {
        cwd: dockerComposePath,
      });

      logger.info('✅ Comando restart enviado');
      return true;

    } catch (error: any) {
      logger.error('❌ Erro ao reiniciar container:', error.message);
      return false;
    }
  }

  /**
   * Verifica se o container Evolution API está rodando e saudável
   */
  private async checkContainerHealth(maxRetries: number = 3): Promise<boolean> {
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        logger.info(`🔍 Verificação de saúde (tentativa ${attempt}/${maxRetries})...`);

        // Aguardar 10 segundos antes de verificar
        await new Promise(resolve => setTimeout(resolve, 10000));

        // 1. Verificar se container está rodando
        const { stdout: psOutput } = await execAsync('docker ps --filter "name=ferraco-evolution" --format "{{.Status}}"');

        if (!psOutput.includes('Up')) {
          logger.warn(`⚠️ Container não está rodando (tentativa ${attempt}/${maxRetries})`);

          if (attempt < maxRetries) {
            logger.info('🔄 Tentando reiniciar novamente...');
            await this.restartEvolutionContainer();
            continue;
          } else {
            logger.error('❌ Container falhou em subir após todas as tentativas');
            return false;
          }
        }

        logger.info('✅ Container está rodando');

        // 2. Verificar logs para erros críticos
        const { stdout: logsOutput } = await execAsync('docker logs ferraco-evolution --tail 50 2>&1');

        if (logsOutput.includes('Error:') || logsOutput.includes('ECONNREFUSED')) {
          logger.warn(`⚠️ Erros detectados nos logs (tentativa ${attempt}/${maxRetries})`);

          if (attempt < maxRetries) {
            logger.info('🔄 Tentando reiniciar novamente...');
            await this.restartEvolutionContainer();
            continue;
          } else {
            logger.error('❌ Container com erros após todas as tentativas');
            return false;
          }
        }

        // 3. Verificar se API responde (health check)
        try {
          const evolutionApiUrl = process.env.EVOLUTION_API_URL || 'http://localhost:8080';
          const axios = require('axios');

          const response = await axios.get(`${evolutionApiUrl}/instance/fetchInstances`, {
            headers: {
              'apikey': process.env.EVOLUTION_API_KEY || 'FERRACO2025',
            },
            timeout: 5000,
          });

          if (response.status === 200) {
            logger.info('✅ Evolution API respondendo corretamente');
            return true;
          }
        } catch (apiError: any) {
          logger.warn(`⚠️ API não responde (tentativa ${attempt}/${maxRetries}): ${apiError.message}`);

          if (attempt < maxRetries) {
            logger.info('🔄 Tentando reiniciar novamente...');
            await this.restartEvolutionContainer();
            continue;
          }
        }

        // Se chegou aqui e não retornou true, algo está errado
        if (attempt === maxRetries) {
          logger.error('❌ Container rodando mas API não responde adequadamente');
          return false;
        }

      } catch (error: any) {
        logger.error(`❌ Erro na verificação de saúde (tentativa ${attempt}/${maxRetries}):`, error.message);

        if (attempt < maxRetries) {
          logger.info('🔄 Tentando reiniciar novamente...');
          await this.restartEvolutionContainer();
          continue;
        } else {
          return false;
        }
      }
    }

    return false;
  }

  /**
   * Faz rollback da versão em caso de falha
   */
  private async rollbackVersion(oldVersion: string): Promise<boolean> {
    try {
      logger.warn('⚠️ Iniciando rollback para versão anterior...');

      const dockerComposePath = path.join(process.cwd(), '../../docker-compose.vps.yml');

      // Ler arquivo
      let content = await fs.readFile(dockerComposePath, 'utf-8');

      // Substituir com versão antiga
      const oldPattern = /CONFIG_SESSION_PHONE_VERSION=[0-9.]+/;
      const oldValue = `CONFIG_SESSION_PHONE_VERSION=${oldVersion}`;

      content = content.replace(oldPattern, oldValue);

      // Salvar
      await fs.writeFile(dockerComposePath, content, 'utf-8');

      logger.info('✅ Rollback do arquivo concluído');

      // Reiniciar container
      await this.restartEvolutionContainer();

      // Verificar saúde
      const healthy = await this.checkContainerHealth(2);

      if (healthy) {
        logger.info('✅ Rollback bem-sucedido. Sistema restaurado para versão anterior.');
        return true;
      } else {
        logger.error('❌ Rollback falhou. Intervenção manual necessária!');
        return false;
      }

    } catch (error: any) {
      logger.error('❌ Erro crítico no rollback:', error.message);
      return false;
    }
  }

  /**
   * Verifica e atualiza a versão se necessário
   */
  async checkAndUpdate(): Promise<VersionCheckResult> {
    if (this.isChecking) {
      return {
        currentVersion: this.currentVersion || 'unknown',
        latestVersion: 'unknown',
        needsUpdate: false,
        updated: false,
        error: 'Verificação já em andamento',
      };
    }

    this.isChecking = true;
    this.lastCheck = new Date();

    try {
      // Recarregar versão atual
      await this.loadCurrentVersion();

      const currentVersion = this.currentVersion;

      if (!currentVersion) {
        throw new Error('Não foi possível determinar versão atual');
      }

      // Buscar versão mais recente
      const latestVersion = await this.fetchLatestVersion();

      // Comparar versões
      const needsUpdate = currentVersion !== latestVersion;

      logger.info('📊 Comparação de versões:', {
        current: currentVersion,
        latest: latestVersion,
        needsUpdate,
      });

      if (!needsUpdate) {
        logger.info('✅ Versão já está atualizada');
        return {
          currentVersion,
          latestVersion,
          needsUpdate: false,
          updated: false,
        };
      }

      // Atualizar arquivo
      logger.info('🔄 Versão desatualizada. Iniciando atualização automática...');

      const updated = await this.updateDockerCompose(latestVersion);

      if (!updated) {
        throw new Error('Falha ao atualizar docker-compose.vps.yml');
      }

      // Reiniciar container Evolution API
      const restarted = await this.restartEvolutionContainer();

      if (!restarted) {
        logger.error('❌ Falha ao reiniciar container. Iniciando rollback...');
        await this.rollbackVersion(currentVersion);
        throw new Error('Falha ao reiniciar container Evolution API');
      }

      // Verificar saúde do container (3 tentativas)
      logger.info('🏥 Verificando saúde do container...');
      const healthy = await this.checkContainerHealth(3);

      if (!healthy) {
        logger.error('❌ Container não passou na verificação de saúde. Iniciando rollback...');
        const rollbackSuccess = await this.rollbackVersion(currentVersion);

        if (!rollbackSuccess) {
          logger.error('🚨 CRÍTICO: Rollback falhou! Intervenção manual URGENTE necessária!');
        }

        throw new Error('Container não passou na verificação de saúde');
      }

      // Sucesso!
      logger.info('🎉 Atualização concluída com sucesso!');
      logger.info(`📱 WhatsApp Web atualizado: ${currentVersion} → ${latestVersion}`);

      // Atualizar versão em memória
      this.currentVersion = latestVersion;

      return {
        currentVersion,
        latestVersion,
        needsUpdate: true,
        updated: true,
      };

    } catch (error: any) {
      logger.error('❌ Erro na verificação/atualização:', error.message);
      return {
        currentVersion: this.currentVersion || 'unknown',
        latestVersion: 'unknown',
        needsUpdate: false,
        updated: false,
        error: error.message,
      };
    } finally {
      this.isChecking = false;
    }
  }

  /**
   * Retorna status do monitor
   */
  getStatus() {
    return {
      currentVersion: this.currentVersion,
      lastCheck: this.lastCheck,
      isChecking: this.isChecking,
    };
  }
}

// Singleton
const whatsappVersionMonitor = new WhatsAppVersionMonitor();
export default whatsappVersionMonitor;
