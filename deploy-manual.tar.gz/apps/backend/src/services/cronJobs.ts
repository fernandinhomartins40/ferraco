/**
 * Cron Jobs - Tarefas agendadas
 *
 * Este arquivo configura todas as tarefas agendadas do sistema:
 * - Verificação de versão do WhatsApp Web (a cada 6 horas)
 * - Limpeza de sessões expiradas (diariamente)
 * - Backup automático (semanalmente)
 */

import { CronJob } from 'cron';
import whatsappVersionMonitor from './whatsappVersionMonitor';
import logger from '../utils/logger';

/**
 * Job: Verificar versão do WhatsApp Web
 * Executa a cada 6 horas
 * Cron: 0 */6 * * * (às 00:00, 06:00, 12:00, 18:00)
 */
const whatsappVersionCheckJob = new CronJob(
  '0 */6 * * *', // A cada 6 horas
  async () => {
    logger.info('⏰ [CRON] Iniciando verificação automática de versão do WhatsApp Web');

    try {
      const result = await whatsappVersionMonitor.checkAndUpdate();

      if (result.updated) {
        logger.info('🎉 [CRON] Versão do WhatsApp Web atualizada automaticamente!', {
          from: result.currentVersion,
          to: result.latestVersion,
        });
      } else if (result.needsUpdate && !result.updated) {
        logger.warn('⚠️ [CRON] Versão precisa de atualização mas falhou:', result.error);
      } else {
        logger.info('✅ [CRON] Versão do WhatsApp Web já está atualizada');
      }
    } catch (error: any) {
      logger.error('❌ [CRON] Erro na verificação automática:', error.message);
    }
  },
  null, // onComplete
  false, // start
  'America/Sao_Paulo' // timezone
);

/**
 * Inicializa todos os cron jobs
 */
export function startCronJobs(): void {
  logger.info('🕐 Iniciando cron jobs...');

  // Iniciar job de verificação de versão
  whatsappVersionCheckJob.start();
  logger.info('✅ Cron job de verificação de versão do WhatsApp Web iniciado (a cada 6 horas)');

  // Executar primeira verificação imediatamente (após 1 minuto de boot)
  setTimeout(async () => {
    logger.info('🚀 Executando primeira verificação de versão do WhatsApp Web...');
    try {
      const result = await whatsappVersionMonitor.checkAndUpdate();
      logger.info('✅ Primeira verificação concluída:', {
        currentVersion: result.currentVersion,
        latestVersion: result.latestVersion,
        needsUpdate: result.needsUpdate,
      });
    } catch (error: any) {
      logger.error('❌ Erro na primeira verificação:', error.message);
    }
  }, 60000); // 1 minuto
}

/**
 * Para todos os cron jobs
 */
export function stopCronJobs(): void {
  logger.info('⏸️ Parando cron jobs...');
  whatsappVersionCheckJob.stop();
  logger.info('✅ Cron jobs parados');
}
