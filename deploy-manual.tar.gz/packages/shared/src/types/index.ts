// Shared TypeScript types
export * from './common';
