// Shared constants
export const API_VERSION = 'v1';
export const DEFAULT_PAGE_SIZE = 10;
export const MAX_PAGE_SIZE = 100;
