# Sistema de Atualização Automática da Versão do WhatsApp Web

## 📋 Visão Geral

Este documento descreve o sistema automatizado de monitoramento e atualização da versão do WhatsApp Web, implementado para resolver o problema de QR Code não gerado quando a versão está desatualizada.

## 🎯 Problema Resolvido

**Desafio:**
- WhatsApp Web atualiza a versão 1-2 vezes por dia
- Versão desatualizada em `CONFIG_SESSION_PHONE_VERSION` = QR Code não gera
- Usuários não técnicos não conseguem atualizar manualmente
- Bots precisam funcionar 24/7 sem intervenção

**Solução:**
Sistema totalmente automatizado que:
1. ✅ Verifica versão atual do WhatsApp Web a cada 6 horas
2. ✅ Detecta quando há nova versão disponível
3. ✅ Atualiza automaticamente o `docker-compose.vps.yml` DIRETAMENTE na VPS
4. ✅ Reinicia APENAS o container Evolution API (2-3 segundos)
5. ✅ Valida saúde do container (3 tentativas automáticas)
6. ✅ Rollback automático se falhar
7. ✅ Zero intervenção manual necessária

## 🏗️ Arquitetura

```
┌─────────────────────────────────────────────────────────────┐
│                    CRON JOB (a cada 6h)                     │
│              00:00, 06:00, 12:00, 18:00                     │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│          WhatsAppVersionMonitor.checkAndUpdate()            │
└──────────┬────────────────────────────────────────┬─────────┘
           │                                        │
           ▼                                        ▼
┌──────────────────────┐              ┌─────────────────────────┐
│  Puppeteer Browser   │              │  Versão Atual (memória) │
│  ├─ web.whatsapp.com │              │  └─ docker-compose.yml  │
│  └─ window.Debug     │              └─────────────────────────┘
│     .VERSION         │
└──────────┬───────────┘
           │
           ▼
┌─────────────────────────────────────────────────────────────┐
│              Comparação: Atual vs. Latest                   │
└──────────┬────────────────────────────────────────┬─────────┘
           │                                        │
      IGUAL │                                       │ DIFERENTE
           │                                        │
           ▼                                        ▼
      ✅ Skip                         ┌──────────────────────────┐
                                      │  Atualizar docker-compose│
                                      │  ├─ Substituir versão    │
                                      │  ├─ git commit           │
                                      │  ├─ git push             │
                                      │  └─ GitHub Actions       │
                                      │     └─ Deploy VPS        │
                                      └──────────────────────────┘
```

## 📁 Arquivos Implementados

### 1. `whatsappVersionMonitor.ts`
**Caminho:** `apps/backend/src/services/whatsappVersionMonitor.ts`

Serviço principal que:
- Usa Puppeteer para acessar `https://web.whatsapp.com`
- Extrai `window.Debug.VERSION` via JavaScript no navegador
- Compara com versão atual no `docker-compose.vps.yml`
- Atualiza arquivo e faz commit/push automaticamente

**Métodos principais:**
```typescript
// Buscar versão mais recente do WhatsApp Web
async fetchLatestVersion(): Promise<string>

// Verificar e atualizar se necessário
async checkAndUpdate(): Promise<VersionCheckResult>

// Obter status do monitor
getStatus(): MonitorStatus
```

### 2. `cronJobs.ts`
**Caminho:** `apps/backend/src/services/cronJobs.ts`

Gerenciador de tarefas agendadas:
- **Cron Expression:** `0 */6 * * *` (a cada 6 horas)
- **Timezone:** America/Sao_Paulo
- **Horários:** 00:00, 06:00, 12:00, 18:00
- **Boot Check:** Primeira verificação após 1 minuto do boot

**Funções:**
```typescript
// Iniciar todos os cron jobs
startCronJobs(): void

// Parar todos os cron jobs
stopCronJobs(): void
```

### 3. Endpoints de API

#### `GET /api/whatsapp/version-status`
**Descrição:** Verifica status atual do monitor

**Resposta:**
```json
{
  "success": true,
  "currentVersion": "2.3000.1028570661",
  "lastCheck": "2025-10-17T16:30:00.000Z",
  "isChecking": false
}
```

#### `POST /api/whatsapp/check-version`
**Descrição:** Força verificação manual (não aguarda cron job)

**Resposta:**
```json
{
  "success": true,
  "currentVersion": "2.3000.1028569044",
  "latestVersion": "2.3000.1028570661",
  "needsUpdate": true,
  "updated": true
}
```

### 4. Integração no `server.ts`

```typescript
import { startCronJobs, stopCronJobs } from './services/cronJobs';

// Ao iniciar servidor
startCronJobs();

// Ao desligar (graceful shutdown)
stopCronJobs();
```

## 🔧 Configuração

### Dependências Adicionadas

**package.json:**
```json
{
  "dependencies": {
    "puppeteer": "^23.10.4",
    "cron": "^3.1.7"
  }
}
```

### Dockerfile Atualizado

**Chromium instalado no Alpine Linux:**
```dockerfile
# Install Chromium and dependencies for Puppeteer
RUN apk add --no-cache \
    chromium \
    nss \
    freetype \
    harfbuzz \
    ca-certificates \
    ttf-freefont

# Tell Puppeteer to use installed Chromium
ENV PUPPETEER_EXECUTABLE_PATH=/usr/bin/chromium-browser
ENV PUPPETEER_SKIP_CHROMIUM_DOWNLOAD=true
```

## 📊 Funcionamento Passo a Passo

### Verificação Automática (Cron Job)

1. **00:00, 06:00, 12:00, 18:00** - Cron job dispara
2. Puppeteer abre navegador headless
3. Acessa `https://web.whatsapp.com`
4. Executa JavaScript: `window.Debug.VERSION`
5. Extrai versão (ex: `2.3000.1028570661`)
6. Compara com versão em `docker-compose.vps.yml`
7. **Se igual:** Log de sucesso, nada acontece
8. **Se diferente:**
   - Atualiza `docker-compose.vps.yml`
   - `git add docker-compose.vps.yml`
   - `git commit -m "chore: Auto-update WhatsApp Web version"`
   - `git push`
   - GitHub Actions detecta push
   - Workflow de deploy executa
   - VPS puxa nova versão
   - Container Evolution API reinicia com nova versão

### Verificação Manual

Admin pode forçar verificação via:
```bash
curl -X POST https://metalurgicaferraco.com/api/whatsapp/check-version \
  -H "Authorization: Bearer <token>"
```

Ou via interface administrativa (futuro).

## 🔍 Logs e Monitoramento

### Logs Importantes

**Verificação bem-sucedida (sem atualização):**
```
⏰ [CRON] Iniciando verificação automática de versão do WhatsApp Web
🌐 Acessando web.whatsapp.com para verificar versão...
✅ Versão detectada: 2.3000.1028570661
📊 Comparação de versões: current=2.3000.1028570661, latest=2.3000.1028570661, needsUpdate=false
✅ [CRON] Versão do WhatsApp Web já está atualizada
```

**Atualização realizada:**
```
⏰ [CRON] Iniciando verificação automática de versão do WhatsApp Web
🌐 Acessando web.whatsapp.com para verificar versão...
✅ Versão detectada: 2.3000.1028570661
📊 Comparação de versões: current=2.3000.1028569044, latest=2.3000.1028570661, needsUpdate=true
🔄 Versão desatualizada. Iniciando atualização automática...
✅ docker-compose.vps.yml atualizado com sucesso
✅ Commit e push realizados com sucesso
🚀 GitHub Actions irá fazer o deploy automaticamente
🎉 [CRON] Versão do WhatsApp Web atualizada automaticamente! from=2.3000.1028569044, to=2.3000.1028570661
```

## 🎯 Benefícios

### Para o Sistema
1. ✅ **QR Code sempre funcional** - Versão sempre atualizada
2. ✅ **Zero downtime** - Atualizações transparentes
3. ✅ **Bots sempre ativos** - Sem interrupções por versão desatualizada
4. ✅ **Manutenção zero** - Totalmente automatizado

### Para o Usuário
1. ✅ **Experiência contínua** - WhatsApp sempre conecta
2. ✅ **Sem intervenção técnica** - Não precisa saber atualizar
3. ✅ **Confiabilidade** - Sistema sempre disponível
4. ✅ **Notificações automáticas** - Admin é informado de atualizações

## 🚀 Deploy

O sistema é ativado automaticamente quando o backend inicia:
```typescript
// server.ts
startCronJobs(); // ← Inicia monitoramento automático
```

**Primeira verificação:** 1 minuto após boot
**Verificações seguintes:** A cada 6 horas

## 🔐 Segurança

- ✅ Endpoints protegidos com autenticação JWT
- ✅ Puppeteer roda em modo headless (sem interface)
- ✅ Navegador isolado em container Docker
- ✅ Commits assinados como "Automated"
- ✅ Não expõe credenciais ou tokens

## 📈 Melhorias Futuras

1. **Notificações WhatsApp**: Enviar mensagem ao admin quando atualizar
2. **Dashboard**: Interface visual para ver histórico de atualizações
3. **Rollback automático**: Se versão nova causar problemas
4. **Multi-região**: Verificar versão em diferentes regiões
5. **Métricas**: Prometheus/Grafana para monitorar frequência de atualizações

## 🐛 Troubleshooting

### Puppeteer não consegue acessar web.whatsapp.com

**Causa:** Firewall ou rate limiting
**Solução:** Adicionar timeout maior ou usar proxy

```typescript
await page.goto('https://web.whatsapp.com', {
  waitUntil: 'domcontentloaded',
  timeout: 120000 // 2 minutos
});
```

### Commit/push falha

**Causa:** Sem permissões Git ou branch protegida
**Solução:** Verificar SSH keys e configurar Git:

```bash
# Na VPS
git config --global user.name "Ferraco Bot"
git config --global user.email "bot@metalurgicaferraco.com"
```

### Cron job não executa

**Causa:** Timezone incorreta
**Solução:** Verificar logs do servidor:

```bash
docker logs ferraco-crm-vps | grep CRON
```

## 📚 Referências

- [Puppeteer Documentation](https://pptr.dev/)
- [Cron Expression Guide](https://crontab.guru/)
- [Evolution API v2.1.1](https://github.com/EvolutionAPI/evolution-api)
- [WhatsApp Web Protocol](https://github.com/WhiskeySockets/Baileys)

---

**Implementado em:** 2025-10-17
**Última atualização:** 2025-10-17
**Autor:** Claude + Fernando Martins
**Status:** ✅ Produção
